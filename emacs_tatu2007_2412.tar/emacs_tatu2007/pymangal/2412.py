# don't waste your time thinking about how this code works, it's fallout happening, you don't have so much time
# GNU GPL
# ^^ yes, plain line of symbols

S1 = ":PROPERTIES:"
S2 = ":END:"

# not import knights
import os, json


# list of files
d = "/home/kianu/left/pyjira24_test_24"

# # print(help(os.walk))

allfiles_raw = list(list(os.walk(d, topdown = True)))
allfiles_GOG = []
for i in allfiles_raw:
    for j in i[-1]:
        az = i[0] + "/" + j
        # # print(az)
        if az.endswith(".org"):
#             # print(az)
            allfiles_GOG.append(az)
        
        
# # print(allfiles_raw)
# # print(allfiles_GOG)


# # define function

# #tatu - put in library
# probably can support multiple strings
def split_without_deleting_delimiter(string_I, delimiter):
    output_list = []

    this_node_pos_begin = 0
    hold = True
    debug_lock = 30
    while hold and debug_lock:
        debug_lock -= 1
        try:
            next_node_pos_begin = string_I[this_node_pos_begin + 2:].index(delimiter) + 2
            output_list.append(string_I[this_node_pos_begin:next_node_pos_begin])
            this_node_pos_begin = next_node_pos_begin
            # print("setting next to " + str(this_node_pos_begin))

        except Exception as e1:
            try:
                "".index("placeholder")
            except Exception as e_substring_not_found:
                exc = e_substring_not_found
            if str(e1) == str(exc):  # string, because 2 exceptions with the same class are not the same
                hold = False
            else:
                # print(e1)
                import sys
                sys.exit()

    return output_list

            
def text_to_nodes(tmp_text):
    # zeroth, nonzeroth = [x,"* " + y for x,y in tmp_text.split('\n* ')
    # zeroth
    if tmp_text.startswith("* "):
        zeroth, others = None, tmp_text
    else:
        zeroth, others = tmp_text.split("\n* ", 1)
        others = "* " + others

    nodes = [zeroth] if zeroth else []

    others = split_without_deleting_delimiter(others, "* ")
        
    nodes = nodes + others

    return nodes


# # BEGIN

nodelist = {}

for I in allfiles_GOG:
    with open(I, mode = "r") as f:
        V = f.read()
        # # print(V)
        X = text_to_nodes(V)
        nodelist[I] = X


# print("XXX nodelist XXX")
# print(nodelist)
# print('\n')

def recalculate_properties_region(structure):
    fulltext = structure["fulltext"]
    if S1 in fulltext and S2 in fulltext:
        II = fulltext.index(S1)
        III = fulltext.index(S2)
        props_region = [II + len(S1) + 1, III]
        structure["props_region"] = props_region

    return structure
        

def read_node_structure(node):
    structure = {"fulltext": node, "mangal_tags": {}, "org_properties": {}, "type_by_orgmode_syntax": None}
    if node.startswith("* "):
        structure["type_by_orgmode_syntax"] = "zeroth"
    else:
        structure["type_by_orgmode_syntax"] = "generic_o"
                         

    structure = recalculate_properties_region(structure)
    if "props_region" in structure.keys():
        props_block_raw = node[structure["props_region"][0]:structure["props_region"][1]-1]
        # print(" XXX PROPS BLOCK RAW XXX ")
        # print(json.dumps(props_block_raw))
        props_block_raw = props_block_raw.split("\n")
        props_block_neat = {}
        for line in props_block_raw:
            line = line[1:]  # delete first semicolon
            # print("LINE\n\n")
            # print(line)
            pair = line.split(": ", 1)
            pair[1] = pair[1].lstrip()
            if pair[0] == "meta":
                pair[1] = json.loads(pair[1])
            props_block_neat[pair[0]] = pair[1]
        
        structure["org_properties"] = props_block_neat

        
    # BEGIN mangal_tags block

    mangalZhashes = ["#"]
    lines = node.split("\n")
    words = []
    for line in lines:
        words_V = line.split(' ')
        words = words + words_V
    
    for word in words:
        if word.startswith("#"):
            structure["mangal_tags"][word] = True

    # END mangal_tags block

    # print("\n RETURNING STRUCTURE \n\n")
    # print(structure)
    return structure


import datetime


def fix_node_structure(structure):
    if "org_properties" in structure.keys():
        op = structure["org_properties"]  # remember it's a pointer to the same object, not copy of that object. Less letters to type : just "op"

        if "meta" not in op.keys():
                op["meta"] = {}

        # print("\n  FLAG 001 \n")
        # print(op)
        meta_keys = op["meta"].keys()

        # if "file" not in meta_keys:
        #     op["meta"]["file"] = None

        if "timestamp" not in meta_keys:
            op["meta"]["timestamp"] = str(datetime.datetime.now())

        # ATTENTION
        # op_meta_baked = json.dumps(op["meta"])
        # op["meta"] = op_meta_baked

        new_structure_X = replace_properties_block(structure)
        return new_structure_X

    return structure
    

    

def replace_properties_block(structure):
    structure = recalculate_properties_region(structure)
    op_freshilybuiltpropsblock = ""

    op = structure["org_properties"]  # remember it's a pointer to the same object, not copy of that object. Less letters to type : just "op"

    for prop in op:
        if type(prop) == type({}):
            prop = json.dumps(prop)
        line = ":" + prop + ":" + " " + prop
        op_freshilybuiltpropsblock += line + "\n"

    fulltext = structure["fulltext"]
    print("\n\n fulltext is \n")
    print(fulltext)

    if S1 in structure["fulltext"] and S2 in structure["fulltext"]:  # if has properties block at all
        region = structure["props_region"]
        updated_fulltext = fulltext[:region[0]] + op_freshilybuiltpropsblock + fulltext[region[1]:]
    else:
        op_freshilybuiltpropsblock = S1 + op_freshilybuiltpropsblock + S2
        if '\n' in fulltext:
            headline_line, inner_line = fulltext.split('\n', 1)
            # print("FLAG_X")
            # print(json.dumps(headline_line))
            # print(json.dumps(inner_line))
        else: 
            headline_line = fulltext
            inner_line = ''
            
        updated_fulltext = headline_line + '\n' + op_freshilybuiltpropsblock + '\n' + inner_line

    print("\n\n afterlife is \n")
    print(updated_fulltext)

    new_structure_M = dict(structure)
    new_structure_M["fulltext"] = updated_fulltext
    new_structure_M = recalculate_properties_region(new_structure_M)

    return new_structure_M


class Structure:
    pass


# debugging block don't delete please
'''
# print("\n\nXXX test XXX\n")
# print(nodelist)        

nlkeys = list(nodelist.keys())
structure_V = read_node_structure(nodelist[nlkeys[0]][1])
# print("\n\n    XXX node structure XXX\n")
# print(structure_V)

structure_V["org_properties"].update({"filepath": nlkeys[0]})
# print("\n\n    XXX updated props with filepath XXX\n")
# print(structure_V)

structure_V = replace_properties_block(structure_V)
# print("\n    XXX after replace properties XXX\n\n")
# print(structure_V)


structure_V = fix_node_structure(structure_V)
# print("\n\n    XXX after fix node structure XXX\n")
# print(structure_V)
'''


# by nodelist here I mean pass dict of type { filename: list_of_texts } like { "/home/.../_.org": ["* node1\nheadlineisnodetoo"] }
def generate_structure_list(nodelist):
    nlkeys = list(nodelist.keys())
    structure_list = []
    for X in nodelist:  # f for file
        for I in nodelist[X]:  # "t" for "text"
            structure_D = structure_V = read_node_structure(I)
            # print("\n  XXX FLAG002 XXX\n\n")
            # print(structure_D)
            structure_D["org_properties"].update({"filepath": X})
            # print("\n  XXX FLAG003 XXX\n\n")
            # print(structure_D)
            structure_D = replace_properties_block(structure_D)
            # print("\n  XXX FLAG004 XXX\n\n")
            # print(structure_D)
            structure_D = fix_node_structure(structure_D)
            # print("\n  XXX FLAG005 XXX\n\n")
            # print(structure_D)

            structure_list.append(structure_D)

    return structure_list


structures_I = generate_structure_list(nodelist)
# print("\n\n    XXX  STRUCTURES_I XXX\n")
# print(structures_I)


def get_node_by_timestamp(S_list, ts_array):
    output = []
    for S in S_list:
        S_ts = S["org_properties"]["meta"]["timestamp"]
        # didn't continue on this




def concat_structure_texts_with_newlines(structures):
    texts_list = []
    for S in structures:
        texts_list.append(S["fulltext"])

    return "\n".join(texts_list)


print(concat_structure_texts_with_newlines(structures_I))


